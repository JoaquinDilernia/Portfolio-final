# Easybank + SASS
I'm learning sass in a live streaming

- This a challenge of frontendmentor.io https://www.frontendmentor.io/challenges/easybank-landing-page-WaUhkoDN
- Watch the live project https://leonidasesteban.github.io/easybank-learning-sass/

![leonidas esteban](https://repository-images.githubusercontent.com/262682282/48d8c100-925d-11ea-867c-2648ee91788b)
