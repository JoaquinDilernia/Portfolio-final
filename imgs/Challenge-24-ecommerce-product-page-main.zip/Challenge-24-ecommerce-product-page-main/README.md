# Frontend Mentor - E-commerce product page

![Design preview for the E-commerce product page coding challenge](./design/desktop-preview.jpg)

## Welcome! 👋

👋 Bienvenidos a CodingTube, un canal dedicado a los apasionados por el código. Si te gusta programar y quieres aprender más acerca de este fascinante mundo, estás en el lugar indicado.

►SíGUEME AQUí:

✅YouTube: https://www.youtube.com/CodingTube

✅TikTok: https://www.tiktok.com/@codingtube

✅WEB: https://coding-tube.com/

✅Twitter: https://twitter.com/CodingTube

✅Discord: https://discord.gg/tasEBrh8Zw

✅Twitch: https://www.twitch.tv/codingtube

✅Facebook: https://www.facebook.com/groups/codingtubers

►CURSOS:

📕HTML5: https://bit.ly/CodingHTML01

📘CSS3: https://bit.ly/CodingCSS01

📙Javascript: http://bit.ly/CodingJS01

►LISTAS DE REPRODUCCIÓN RECOMENDADAS:

📒Etiquetas HTML: https://bit.ly/HTMLShorts

📗Todos los retos frontend: https://bit.ly/CodingRetos

►CLASES PARTICULARES:

👨‍🏫Reserva una clase gratuita de 20 minutos aquí: https://www.classgap.com/me/david-577169